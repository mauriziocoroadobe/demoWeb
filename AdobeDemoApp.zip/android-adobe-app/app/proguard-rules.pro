
# Adobe Experience Platform SDK
-keep class com.adobe.marketing.mobile.** { *; }
-keep interface com.adobe.marketing.mobile.** { *; }
-keepclassmembers class com.adobe.marketing.mobile.** { *; }
-dontwarn com.adobe.marketing.mobile.**

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }
