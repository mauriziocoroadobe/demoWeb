package com.adobe.demoapp

import android.app.Application
import android.util.Log
import com.adobe.marketing.mobile.Assurance
import com.adobe.marketing.mobile.Edge
import com.adobe.marketing.mobile.Lifecycle
import com.adobe.marketing.mobile.LoggingMode
import com.adobe.marketing.mobile.MobileCore
import com.adobe.marketing.mobile.Signal
import com.adobe.marketing.mobile.UserProfile
import com.adobe.marketing.mobile.edge.consent.Consent
import com.adobe.marketing.mobile.edge.identity.Identity as EdgeIdentity
import com.adobe.marketing.mobile.Messaging
import com.adobe.marketing.mobile.optimize.Optimize

class AdobeDemoApplication : Application() {

    companion object {
        private const val TAG = "AdobeDemoApp"
        private const val LAUNCH_ENVIRONMENT_FILE_ID =
            "462a5230b455/94869a1ef882/launch-e22bd9c54337-development"
    }

    override fun onCreate() {
        super.onCreate()
        initAdobeSDK()
    }

    private fun initAdobeSDK() {
        MobileCore.setLogLevel(if (BuildConfig.ENABLE_ASSURANCE) LoggingMode.VERBOSE else LoggingMode.WARNING)
        MobileCore.setApplication(this)

        val extensions = buildList {
            add(Lifecycle.EXTENSION)
            add(Signal.EXTENSION)
            add(com.adobe.marketing.mobile.Identity.EXTENSION)
            add(UserProfile.EXTENSION)
            add(Edge.EXTENSION)
            add(EdgeIdentity.EXTENSION)
            add(Consent.EXTENSION)
            add(Optimize.EXTENSION)
            add(Messaging.EXTENSION)
            if (BuildConfig.ENABLE_ASSURANCE) add(Assurance.EXTENSION)
        }

        MobileCore.registerExtensions(extensions) {
            // ORDINE CRITICO — tutto qui dentro, dopo che gli SDK sono pronti:

            // 1. Configura l'app con l'Environment File ID
            MobileCore.configureWithAppID(LAUNCH_ENVIRONMENT_FILE_ID)

            // 2. Registra il listener per le risposte di Target
            //    DEVE essere prima di qualsiasi updatePropositions
            TargetManager.registerPropositionsUpdateHandler()

            // 3. Carica il loyalty level salvato e imposta il profilo
            val loyalty = LoyaltyLevel.load(applicationContext)
            LoyaltyLevel.setCurrent(applicationContext, loyalty)
            TargetManager.setUserProfileAttributes(loyalty)

            // 4. Prefetch offerte — ora configureWithAppID è già stato chiamato
            //    e il handler è registrato: le risposte arriveranno correttamente
            TargetManager.prefetchAllOffers(loyalty)

            // 5. Registra il token FCM
            PushPermissionHelper.fetchAndRegisterToken()

            // 6. Notifica AssuranceManager che l'SDK è pronto
            //    Processa eventuali URI ricevuti prima dell'init (deep link su cold start)
            AssuranceManager.onSdkReady()

            Log.d(TAG, "Adobe SDK ready — config + handler + prefetch + push token completati (loyalty=${loyalty.key})")
        }
    }
}
