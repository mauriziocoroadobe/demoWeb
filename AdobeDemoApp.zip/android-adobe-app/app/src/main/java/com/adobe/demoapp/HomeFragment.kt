package com.adobe.demoapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import coil.load
import coil.transform.RoundedCornersTransformation
import com.adobe.demoapp.databinding.FragmentHomeBinding

/**
 * HomeFragment — location Target: "home_hero_banner"
 *
 * Tracking:
 *  • onResume         → screenView "Home"
 *  • offerta caricata → notifyDisplay(MBOX_HOME_BANNER)
 *  • btnOfferCta      → notifyClick + ctaInteraction "home_offer_cta"
 *  • btnPromo         → ctaInteraction "home_promo"
 *  • btnNewArrivals   → ctaInteraction "home_new_arrivals"
 *  • btnNewsletter    → ctaInteraction "home_newsletter"
 */
class HomeFragment : Fragment(), TargetOfferHost {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    companion object {
        const val SCREEN_NAME    = "Home"
        const val SCREEN_SECTION = "Main"

        val DEFAULT_OFFER = TargetOffer(
            screen             = "home",
            title              = "Today's picks, curated for you",
            body               = "We handpicked the best products based on your profile.",
            backgroundImageUrl = "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&q=80&auto=format&fit=crop",
            ctaLabel           = "Explore offers",
            ctaTrackingId      = "home_offer_cta_default"
        )
    }

    private var currentOffer: TargetOffer = DEFAULT_OFFER

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        applyOffer(DEFAULT_OFFER)
        setupClickListeners()
        loadTargetOffer()
    }

    /**
     * Chiamato al primo avvio dell'app (Activity fresh start).
     */
    override fun onResume() {
        super.onResume()
        if (!isHidden) trackScreen()
    }

    /**
     * Chiamato ad ogni cambio tab con show()/hide().
     * È l'unico lifecycle che scatta quando si torna su questo Fragment
     * senza ricreare l'Activity.
     */
    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden) trackScreen()
    }

    private fun trackScreen() {
        AEPTracker.trackScreenView(SCREEN_NAME, SCREEN_SECTION)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    // ─── TARGET ──────────────────────────────────────────────────────────────

    override fun reloadTargetOffer() {
        loadTargetOffer()
    }

    private fun loadTargetOffer() {
        TargetManager.getJsonOffer(
            mboxName     = TargetManager.MBOX_HOME_BANNER,
            defaultOffer = DEFAULT_OFFER,
            loyalty      = LoyaltyLevel.CURRENT,
            extraMboxParams = mapOf("screenContext" to "home")
        ) { offer ->
            activity?.runOnUiThread {
                applyOffer(offer)
                TargetManager.notifyDisplay(TargetManager.MBOX_HOME_BANNER)
            }
        }
    }

    private fun applyOffer(offer: TargetOffer) {
        currentOffer = offer
        binding.tvHeroTitle.text = offer.title
        binding.tvHeroBody.text  = offer.body
        binding.btnHeroCta.text  = offer.ctaLabel
        binding.ivHeroBg.load(offer.backgroundImageUrl) {
            crossfade(true)
            error(android.R.drawable.ic_menu_gallery)
        }
    }

    // ─── CTA ─────────────────────────────────────────────────────────────────

    private fun setupClickListeners() {
        binding.btnHeroCta.setOnClickListener {
            AEPTracker.trackCtaInteraction(currentOffer.ctaTrackingId, currentOffer.ctaLabel, SCREEN_NAME, "hero_banner")
            TargetManager.notifyClick(TargetManager.MBOX_HOME_BANNER)
        }
        binding.btnPromo.setOnClickListener {
            AEPTracker.trackCtaInteraction("home_promo", "Today's promotions", SCREEN_NAME, "quick_actions")
        }
        binding.btnNewArrivals.setOnClickListener {
            AEPTracker.trackCtaInteraction("home_new_arrivals", "New arrivals", SCREEN_NAME, "quick_actions")
        }
        binding.btnNewsletter.setOnClickListener {
            AEPTracker.trackCtaInteraction("home_newsletter", "Subscribe to newsletter", SCREEN_NAME, "quick_actions")
        }
    }
}
