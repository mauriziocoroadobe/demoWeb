package com.adobe.demoapp

import android.util.Log
import org.json.JSONException
import org.json.JSONObject

/**
 * TargetOffer — modello dati JSON restituito da Adobe Target.
 *
 * Struttura attesa:
 * {
 *   "screen":              "home",
 *   "title":               "...",
 *   "body":                "...",
 *   "backgroundImageUrl":  "https://...",
 *   "cta": { "label": "...", "trackingId": "..." }
 * }
 */
data class TargetOffer(
    val screen: String,
    val title: String,
    val body: String,
    val backgroundImageUrl: String,
    val ctaLabel: String,
    val ctaTrackingId: String
) {
    companion object {
        private const val TAG = "TargetOffer"

        fun fromJson(json: String?): TargetOffer? {
            if (json.isNullOrBlank()) return null
            return try {
                val root = JSONObject(json)
                val cta  = root.getJSONObject("cta")
                TargetOffer(
                    screen             = root.optString("screen",             ""),
                    title              = root.optString("title",              ""),
                    body               = root.optString("body",               ""),
                    backgroundImageUrl = root.optString("backgroundImageUrl", ""),
                    ctaLabel           = cta.optString("label",      "Continue"),
                    ctaTrackingId      = cta.optString("trackingId", "")
                )
            } catch (e: JSONException) {
                Log.e(TAG, "JSON parse error: ${e.message}")
                null
            }
        }
    }

    fun toJson(): String =
        JSONObject()
            .put("screen", screen)
            .put("title",  title)
            .put("body",   body)
            .put("backgroundImageUrl", backgroundImageUrl)
            .put("cta", JSONObject()
                .put("label",      ctaLabel)
                .put("trackingId", ctaTrackingId)
            )
            .toString()
}
