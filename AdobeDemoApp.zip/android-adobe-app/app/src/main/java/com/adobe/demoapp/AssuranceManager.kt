package com.adobe.demoapp

import android.content.Intent
import android.net.Uri
import android.util.Log
import com.adobe.marketing.mobile.Assurance

object AssuranceManager {

    private const val TAG = "AssuranceManager"
    private const val ASSURANCE_SCHEME = "adobedemoapp"

    /**
     * URI ricevuto prima che l'SDK fosse pronto.
     * Viene processato appena registerExtensions completa.
     */
    private var pendingUri: String? = null

    // ─── CHIAMATO DALL'ACTIVITY ───────────────────────────────────────────────

    fun handleIntent(intent: Intent?): Boolean {
        val uri = intent?.data ?: return false
        return handleDeepLink(uri)
    }

    fun handleDeepLink(uri: Uri): Boolean {
        Log.d(TAG, "Deep link received: $uri")
        if (!isAssuranceUri(uri)) return false

        val uriString = uri.toString()

        if (isSdkReady) {
            Log.d(TAG, "SDK ready — starting Assurance session immediately")
            Assurance.startSession(uriString)
        } else {
            Log.d(TAG, "SDK not ready yet — queuing Assurance URI")
            pendingUri = uriString
        }
        return true
    }

    fun startSessionFromUrl(assuranceUrl: String) {
        if (assuranceUrl.isBlank()) return

        // Se l'utente incolla solo l'ID, costruiamo l'URL completo
        val url = if (assuranceUrl.startsWith(ASSURANCE_SCHEME) || assuranceUrl.startsWith("http")) {
            assuranceUrl
        } else {
            "$ASSURANCE_SCHEME://?adb_validation_sessionid=$assuranceUrl"
        }

        Log.d(TAG, "startSessionFromUrl: isSdkReady=$isSdkReady url=$url")

        if (isSdkReady) {
            Assurance.startSession(url)
        } else {
            pendingUri = url
            Log.d(TAG, "SDK not ready — URI queued, will be processed after init")
        }
    }

    // ─── CHIAMATO DA AdobeDemoApplication DOPO registerExtensions ─────────────

    /**
     * Da chiamare alla fine del callback di registerExtensions.
     * Processa eventuali URI ricevuti prima che l'SDK fosse pronto.
     */
    fun onSdkReady() {
        isSdkReady = true
        pendingUri?.let { uri ->
            Log.d(TAG, "SDK now ready — processing pending Assurance URI")
            Assurance.startSession(uri)
            pendingUri = null
        }
    }

    // ─── PRIVATE ─────────────────────────────────────────────────────────────

    private var isSdkReady = false

    private fun isAssuranceUri(uri: Uri): Boolean {
        val isCustomScheme = uri.scheme == ASSURANCE_SCHEME
        val isHttpsLink    = (uri.scheme == "https" || uri.scheme == "http") &&
                              uri.path?.startsWith("/assurance") == true
        val hasSessionId   = uri.getQueryParameter("adb_validation_sessionid") != null
        return (isCustomScheme || isHttpsLink) && hasSessionId
    }
}
