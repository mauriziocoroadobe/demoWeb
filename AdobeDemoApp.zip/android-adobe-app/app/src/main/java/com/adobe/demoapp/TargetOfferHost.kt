package com.adobe.demoapp

/**
 * Interfaccia implementata dai Fragment che mostrano un'offerta Target.
 * Consente a MainActivity di forzare il reload dell'offerta dopo
 * un cambio di loyalty level senza dover conoscere il tipo specifico del Fragment.
 */
interface TargetOfferHost {
    fun reloadTargetOffer()
}
