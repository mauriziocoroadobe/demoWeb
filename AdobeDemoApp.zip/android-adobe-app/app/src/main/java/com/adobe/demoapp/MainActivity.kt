package com.adobe.demoapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.adobe.demoapp.databinding.ActivityMainBinding
import com.adobe.marketing.mobile.MobileCore
import com.adobe.marketing.mobile.Messaging
import com.adobe.marketing.mobile.edge.identity.AuthenticatedState
import com.adobe.marketing.mobile.edge.identity.Identity as EdgeIdentity
import com.adobe.marketing.mobile.edge.identity.IdentityItem
import com.adobe.marketing.mobile.edge.identity.IdentityMap

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val homeFragment    = HomeFragment()
    private val catalogFragment = CatalogFragment()
    private val profileFragment = ProfileFragment()
    private var activeFragment: Fragment = homeFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupFragments()
        setupBottomNavigation()
        AssuranceManager.handleIntent(intent)

        PushPermissionHelper.init(this)
        PushPermissionHelper.requestNotificationPermission(this)

        handlePushIntent(intent)

        // Gestisci il web_ecid passato dalla pagina web nel deep link
        handleWebEcidIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        MobileCore.lifecycleStart(null)
    }

    override fun onPause() {
        super.onPause()
        MobileCore.lifecyclePause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        AssuranceManager.handleIntent(intent)
        handlePushIntent(intent)
        handleWebEcidIntent(intent)
    }

    /**
     * Legge il parametro web_ecid dal deep link (adobedemoapp://?web_ecid=XXX)
     * e lo aggiunge all'identity map con namespace ECID, primary = false.
     *
     * In questo modo AEP riceve entrambi gli ECID in ogni evento Edge:
     *   ECID[0] → ECID nativo dell'app  (primary: true)  — gestito automaticamente dall'SDK
     *   ECID[1] → ECID web della pagina  (primary: false) — aggiunto qui
     *
     * Questo è il meccanismo standard per la riconciliazione web→app
     * in Real-Time CDP e CJA: i due profili anonimi vengono uniti
     * grazie all'ECID condiviso.
     */
    private fun handleWebEcidIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        val webEcid = uri.getQueryParameter("web_ecid")?.takeIf { it.isNotBlank() } ?: return

        Log.d("MainActivity", "Web ECID received from deep link: $webEcid")

        // Salva in memoria per la UI del ProfileFragment
        WebEcidHolder.set(webEcid)

        // Costruisce l'IdentityMap con il web ECID come identità secondaria
        val identityMap = IdentityMap()
        val identityItem = IdentityItem(
            webEcid,
            AuthenticatedState.AMBIGUOUS,
            false     // primary = false: l'ECID nativo dell'app resta primary
        )
        identityMap.addItem(identityItem, "ECID")

        EdgeIdentity.updateIdentities(identityMap)

        Log.d("MainActivity", "Web ECID added to identity map (primary=false)")

        // Notifica il ProfileFragment di aggiornare la UI se è visibile
        (activeFragment as? ProfileFragment)?.refreshWebEcid()
    }

    private fun handlePushIntent(intent: Intent?) {
        intent ?: return
        Messaging.handleNotificationResponse(intent, true, null)
    }

    fun onLoyaltyLevelChanged(newLevel: LoyaltyLevel) {
        LoyaltyLevel.setCurrent(this, newLevel)
        TargetManager.setUserProfileAttributes(newLevel)
        TargetManager.clearCache()
        TargetManager.prefetchAllOffers(newLevel) {
            runOnUiThread {
                (activeFragment as? TargetOfferHost)?.reloadTargetOffer()
            }
        }
    }

    private fun setupFragments() {
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, profileFragment, "profile").hide(profileFragment)
            .add(R.id.fragment_container, catalogFragment, "catalog").hide(catalogFragment)
            .add(R.id.fragment_container, homeFragment, "home")
            .commit()
    }

    private fun setupBottomNavigation() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home    -> switchTo(homeFragment)
                R.id.nav_catalog -> switchTo(catalogFragment)
                R.id.nav_profile -> switchTo(profileFragment)
            }
            true
        }
    }

    private fun switchTo(target: Fragment) {
        if (target === activeFragment) return
        supportFragmentManager.beginTransaction()
            .hide(activeFragment).show(target).commit()
        activeFragment = target
    }

    private fun getActiveScreenName() = when (activeFragment) {
        is HomeFragment    -> HomeFragment.SCREEN_NAME
        is CatalogFragment -> CatalogFragment.SCREEN_NAME
        is ProfileFragment -> ProfileFragment.SCREEN_NAME
        else               -> "Unknown"
    }
}
