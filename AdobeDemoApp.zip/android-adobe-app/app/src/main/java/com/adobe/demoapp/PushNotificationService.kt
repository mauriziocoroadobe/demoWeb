package com.adobe.demoapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import com.adobe.marketing.mobile.MobileCore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * PushNotificationService
 *
 * Gestisce token FCM e notifiche push in foreground.
 *
 * In v3 dell'AEP Messaging SDK, handleRemoteMessage() è stato rimosso.
 * Il tracking delle notifiche (impression, tap) viene gestito in MainActivity
 * tramite Messaging.handleNotificationResponse().
 *
 * - Background/App chiusa: FCM mostra la notifica automaticamente
 * - Foreground: costruiamo la notifica manualmente con NotificationCompat
 */
class PushNotificationService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "PushNotificationService"
        private const val CHANNEL_ID = "ajo_push_channel"
        private const val CHANNEL_NAME = "Adobe Journey Optimizer"
    }

    /**
     * Chiamato quando FCM genera o rinnova il token.
     * Il token viene registrato in AJO tramite MobileCore.setPushIdentifier().
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "Nuovo FCM token ricevuto — registrazione in AJO")
        MobileCore.setPushIdentifier(token)
    }

    /**
     * Chiamato quando arriva una push con app in FOREGROUND.
     * In background/app chiusa FCM gestisce tutto automaticamente.
     *
     * Costruiamo la notifica manualmente e aggiungiamo un intent verso
     * MainActivity che permette a Messaging.handleNotificationResponse()
     * di tracciare il tap.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "Push ricevuta in foreground — from: ${remoteMessage.from}")

        // Estrai titolo e body dal payload AJO (notification o data)
        val title = remoteMessage.notification?.title
            ?: remoteMessage.data["title"]
            ?: "Adobe Demo App"
        val body = remoteMessage.notification?.body
            ?: remoteMessage.data["body"]
            ?: ""

        showForegroundNotification(title, body, remoteMessage.data)
    }

    // ─── PRIVATE ─────────────────────────────────────────────────────────────

    private fun showForegroundNotification(
        title: String,
        body: String,
        data: Map<String, String>
    ) {
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Crea il canale (necessario da Android 8+)
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        )
        notificationManager.createNotificationChannel(channel)

        // Intent verso MainActivity — include i dati AJO per il tracking
        val tapIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            data.forEach { (key, value) -> putExtra(key, value) }
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            System.currentTimeMillis().toInt(),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_home)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        Log.d(TAG, "Notifica foreground mostrata: $title")
    }
}
