package com.adobe.demoapp

import android.util.Log
import com.adobe.marketing.mobile.Edge
import com.adobe.marketing.mobile.ExperienceEvent
import com.adobe.marketing.mobile.UserProfile
import com.adobe.marketing.mobile.optimize.DecisionScope
import com.adobe.marketing.mobile.optimize.Optimize
import com.adobe.marketing.mobile.optimize.OptimizeProposition

/**
 * TargetManager — Optimize extension wrapper (AEP SDK v3).
 *
 * ARCHITETTURA CORRETTA:
 *
 *  Il pattern "updatePropositions → getPropositions immediato" è una race
 *  condition: getPropositions legge prima che la rete risponda e restituisce
 *  null → fallback al DEFAULT → appare sempre l'offerta di default.
 *
 *  Pattern corretto:
 *  1. registerPropositionsUpdateHandler() → ascolta le risposte di Target
 *     e popola propositionCache quando arrivano
 *  2. updatePropositions() → triggera la chiamata di rete
 *  3. Quando Target risponde, onPropositionsUpdate popola la cache
 *     e notifica i pendingCallbacks registrati dai Fragment
 *  4. getJsonOffer() → se cache hit, consegna subito;
 *     se cache miss, registra un pendingCallback e triggera update
 */
object TargetManager {

    private const val TAG = "TargetManager"

    const val MBOX_HOME_BANNER    = "home_hero_banner"
    const val MBOX_CATALOG_BANNER = "catalog_product_banner"
    const val MBOX_PROFILE_OFFER  = "profile_loyalty_offer"

    /** Proposition complete con scopeDetails, popolate dal callback SDK */
    private val propositionCache = mutableMapOf<String, OptimizeProposition>()

    /**
     * Callback in attesa di risposta Target, per scope name.
     * Quando onPropositionsUpdate notifica un aggiornamento,
     * i callback vengono invocati e rimossi.
     */
    private val pendingCallbacks = mutableMapOf<String, (TargetOffer) -> Unit>()

    /** Default offer per mbox, usato dai pendingCallbacks come fallback */
    private val defaultOffers = mutableMapOf<String, TargetOffer>()

    /**
     * Da chiamare UNA VOLTA in AdobeDemoApplication.onCreate, dopo
     * MobileCore.registerExtensions. Registra il listener globale che
     * popola propositionCache ogni volta che Target risponde.
     */
    fun registerPropositionsUpdateHandler() {
        Optimize.onPropositionsUpdate { propositionsMap ->
            propositionsMap?.forEach { (scope, proposition) ->
                val mboxName = scope.name
                propositionCache[mboxName] = proposition
                Log.d(TAG, "onPropositionsUpdate [$mboxName] " +
                    "id=${proposition.id} " +
                    "correlationID=${proposition.scopeDetails?.get("correlationID")}")

                // Notifica i Fragment che stavano aspettando questa risposta
                pendingCallbacks.remove(mboxName)?.let { callback ->
                    val offer = TargetOffer.fromJson(
                        proposition.offers.firstOrNull()?.content
                    ) ?: defaultOffers[mboxName] ?: return@let
                    callback.invoke(offer)
                }
            }
        }
        Log.d(TAG, "onPropositionsUpdate handler registered")
    }

    // ─── PROFILO UTENTE ───────────────────────────────────────────────────────

    fun setUserProfileAttributes(loyalty: LoyaltyLevel) {
        UserProfile.updateUserAttributes(
            mapOf(
                "loyaltyLevel" to loyalty.key,
                "loyaltyTier"  to loyalty.displayName,
                "platform"     to "android",
                "appVersion"   to BuildConfig.VERSION_NAME
            )
        )
        Log.d(TAG, "UserProfile set → loyaltyLevel=${loyalty.key}")
    }

    // ─── PREFETCH ─────────────────────────────────────────────────────────────

    /**
     * Triggera il download delle offerte per tutte e 3 le location.
     * Il risultato arriva in modo asincrono tramite onPropositionsUpdate.
     */
    fun prefetchAllOffers(
        loyalty: LoyaltyLevel = LoyaltyLevel.CURRENT,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val scopes = listOf(
            DecisionScope(MBOX_HOME_BANNER),
            DecisionScope(MBOX_CATALOG_BANNER),
            DecisionScope(MBOX_PROFILE_OFFER)
        )
        Optimize.updatePropositions(scopes, null, buildTargetData(loyalty))
        Log.d(TAG, "Prefetch triggered for ${scopes.size} locations (loyalty=${loyalty.key})")
        // onComplete viene chiamato subito: il completamento reale
        // arriva tramite onPropositionsUpdate → propositionCache
        onComplete(true)
    }

    // ─── GET OFFER ────────────────────────────────────────────────────────────

    /**
     * Consegna l'offerta per [mboxName]:
     * - Cache hit  → consegna immediata
     * - Cache miss → registra pendingCallback + triggera updatePropositions.
     *               Il callback sarà invocato da onPropositionsUpdate
     *               quando Target risponde.
     */
    fun getJsonOffer(
        mboxName: String,
        defaultOffer: TargetOffer,
        loyalty: LoyaltyLevel = LoyaltyLevel.CURRENT,
        extraMboxParams: Map<String, String> = emptyMap(),
        onOffer: (TargetOffer) -> Unit
    ) {
        // Salva il default per questo mbox (usato come fallback nel handler)
        defaultOffers[mboxName] = defaultOffer

        val cached = propositionCache[mboxName]
        if (cached != null) {
            Log.d(TAG, "Cache hit [$mboxName]")
            onOffer(TargetOffer.fromJson(cached.offers.firstOrNull()?.content) ?: defaultOffer)
            return
        }

        // Cache miss: registra callback e triggera la fetch
        Log.d(TAG, "Cache miss [$mboxName] — registering pending callback + triggering update")
        pendingCallbacks[mboxName] = onOffer

        val data = buildTargetData(loyalty, extraMboxParams)
        Optimize.updatePropositions(listOf(DecisionScope(mboxName)), null, data)
        // La risposta arriverà in onPropositionsUpdate → pendingCallbacks[mboxName]
    }

    // ─── TRACKING ─────────────────────────────────────────────────────────────

    fun notifyDisplay(mboxName: String) {
        val proposition = propositionCache[mboxName] ?: run {
            Log.w(TAG, "notifyDisplay: no cached proposition for $mboxName")
            return
        }
        val xdm = buildPropositionXdm("decisioning.propositionDisplay", mapOf("display" to 1), proposition, mboxName)
        Edge.sendEvent(ExperienceEvent.Builder().setXdmSchema(xdm).build()) { }
        Log.d(TAG, "Display tracked [$mboxName] correlationID=${proposition.scopeDetails?.get("correlationID")}")
    }

    fun notifyClick(mboxName: String) {
        val proposition = propositionCache[mboxName] ?: run {
            Log.w(TAG, "notifyClick: no cached proposition for $mboxName")
            return
        }
        val xdm = buildPropositionXdm("decisioning.propositionInteract", mapOf("interact" to 1), proposition, mboxName)
        Edge.sendEvent(ExperienceEvent.Builder().setXdmSchema(xdm).build()) { }
        Log.d(TAG, "Click tracked [$mboxName] correlationID=${proposition.scopeDetails?.get("correlationID")}")
    }

    fun clearCache() {
        Optimize.clearCachedPropositions()
        propositionCache.clear()
        pendingCallbacks.clear()
        Log.d(TAG, "All caches cleared")
    }

    // ─── PRIVATE ─────────────────────────────────────────────────────────────

    private fun buildPropositionXdm(
        eventType: String,
        eventFlag: Map<String, Int>,
        proposition: OptimizeProposition,
        mboxName: String
    ): Map<String, Any> {
        val entry = mutableMapOf<String, Any>(
            "id"    to (proposition.id ?: ""),
            "scope" to mboxName
        )
        val scopeDetails: Map<String, Any>? = proposition.scopeDetails
        if (!scopeDetails.isNullOrEmpty()) entry["scopeDetails"] = scopeDetails

        return mapOf(
            "eventType" to eventType,
            "_experience" to mapOf(
                "decisioning" to mapOf(
                    "propositionEventType" to eventFlag,
                    "propositions"         to listOf(entry)
                )
            )
        )
    }

    private fun buildTargetData(
        loyalty: LoyaltyLevel,
        extraMboxParams: Map<String, String> = emptyMap()
    ): Map<String, Any> {
        val params = mutableMapOf(
            "loyaltyLevel"         to loyalty.key,
            "platform"             to "android",
            "appVersion"           to BuildConfig.VERSION_NAME,
            "profile.loyaltyLevel" to loyalty.key,
            "profile.loyaltyTier"  to loyalty.displayName
        )
        params.putAll(extraMboxParams)
        return mapOf("__adobe" to mapOf("target" to params))
    }
}
