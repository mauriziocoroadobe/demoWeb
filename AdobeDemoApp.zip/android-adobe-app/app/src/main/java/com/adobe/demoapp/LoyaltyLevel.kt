package com.adobe.demoapp

import android.content.Context

enum class LoyaltyLevel(
    val key: String,
    val displayName: String,
    val pointsRange: String,
    val badgeEmoji: String
) {
    BRONZE(key = "bronze", displayName = "Bronze", pointsRange = "0 – 999 pts",      badgeEmoji = "🥉"),
    SILVER(key = "silver", displayName = "Silver", pointsRange = "1.000 – 4.999 pts", badgeEmoji = "🥈"),
    GOLD(  key = "gold",   displayName = "Gold",   pointsRange = "5.000+ pts",         badgeEmoji = "🥇");

    companion object {
        private const val PREFS_NAME = "demoapp_prefs"
        private const val PREFS_KEY  = "loyalty_level"

        /** Livello attivo — letto da SharedPreferences, default SILVER */
        fun load(context: Context): LoyaltyLevel {
            val key = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(PREFS_KEY, SILVER.key) ?: SILVER.key
            return entries.firstOrNull { it.key == key } ?: SILVER
        }

        /** Salva il livello scelto su SharedPreferences */
        fun save(context: Context, level: LoyaltyLevel) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(PREFS_KEY, level.key)
                .apply()
        }

        /**
         * Livello corrente in memoria — aggiornato da MainActivity.
         * Usato dai Fragment senza dover passare il Context ovunque.
         */
        var CURRENT: LoyaltyLevel = SILVER
            private set

        fun setCurrent(context: Context, level: LoyaltyLevel) {
            CURRENT = level
            save(context, level)
        }
    }
}
