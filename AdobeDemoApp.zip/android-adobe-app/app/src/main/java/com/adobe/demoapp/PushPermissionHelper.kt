package com.adobe.demoapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging

/**
 * PushPermissionHelper
 *
 * Gestisce la richiesta del permesso POST_NOTIFICATIONS (Android 13+)
 * e la registrazione del token FCM verso AJO.
 */
object PushPermissionHelper {

    private const val TAG = "PushPermissionHelper"

    private var permissionLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null

    /**
     * Registra il launcher per la permission dialog.
     * Da chiamare in Activity.onCreate.
     */
    fun init(activity: AppCompatActivity) {
        permissionLauncher = activity.registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                Log.d(TAG, "POST_NOTIFICATIONS: concesso")
                fetchAndRegisterToken()
            } else {
                Log.w(TAG, "POST_NOTIFICATIONS: negato — le push non saranno mostrate")
            }
        }
    }

    /**
     * Richiede il permesso push (Android 13+) e poi registra il token FCM.
     */
    fun requestNotificationPermission(activity: AppCompatActivity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    activity,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    Log.d(TAG, "Permesso già concesso — registrazione token FCM")
                    fetchAndRegisterToken()
                }
                else -> {
                    Log.d(TAG, "Richiesta permesso POST_NOTIFICATIONS")
                    permissionLauncher?.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        } else {
            // Android < 13: notifiche abilitate per default
            fetchAndRegisterToken()
        }
    }

    /**
     * Recupera il token FCM e lo registra in AJO via MobileCore.setPushIdentifier().
     */
    fun fetchAndRegisterToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.e(TAG, "Impossibile ottenere il token FCM: ${task.exception?.message}")
                return@addOnCompleteListener
            }
            val token = task.result
            com.adobe.marketing.mobile.MobileCore.setPushIdentifier(token)
            Log.d(TAG, "Token FCM registrato in AJO")
        }
    }
}
