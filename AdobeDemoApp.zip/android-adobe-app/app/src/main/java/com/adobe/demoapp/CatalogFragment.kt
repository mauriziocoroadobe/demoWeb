package com.adobe.demoapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import coil.load
import com.adobe.demoapp.AEPTracker.CommerceEventType
import com.adobe.demoapp.AEPTracker.Product
import com.adobe.demoapp.databinding.FragmentCatalogBinding

/**
 * CatalogFragment — location Target: "catalog_product_banner"
 *
 * Parametri inviati a Target con ogni request:
 *   loyaltyLevel  = "silver"   (da LoyaltyLevel.CURRENT)
 *   loyaltyTier   = "Silver"
 *   screenContext = "catalog"
 *   platform      = "android"
 *
 * Audience Target suggerite:
 *   profile.loyaltyLevel == "bronze"  → Experience A (offerta base)
 *   profile.loyaltyLevel == "silver"  → Experience B (offerta intermedia)
 *   profile.loyaltyLevel == "gold"    → Experience C (offerta premium)
 *
 * Tracking:
 *  • onResume              → screenView "Catalog"
 *  • offerta caricata      → notifyDisplay(MBOX_CATALOG_BANNER)
 *  • btnCatalogOfferCta    → notifyClick + ctaInteraction
 *  • btnViewProduct_N      → ctaInteraction + commerce.productViews
 *  • btnAddCart_N          → ctaInteraction + commerce.productListAdds
 */
class CatalogFragment : Fragment(), TargetOfferHost {

    private var _binding: FragmentCatalogBinding? = null
    private val binding get() = _binding!!

    companion object {
        const val SCREEN_NAME    = "Catalog"
        const val SCREEN_SECTION = "Commerce"

        val DEFAULT_OFFER = TargetOffer(
            screen             = "catalog",
            title              = "New arrivals for you",
            body               = "Top-rated products this week — free shipping over €49.",
            backgroundImageUrl = "https://images.unsplash.com/photo-1532062009305-80b8e3fa56a6?w=1200&q=80&auto=format&fit=crop",
            ctaLabel           = "Go to profile",
            ctaTrackingId      = "catalog_offer_cta_default"
        )
    }

    private var currentOffer: TargetOffer = DEFAULT_OFFER

    private val products = listOf(
        Product("Product Alpha", "ALPHA-001", 1, 29.99),
        Product("Product Beta",  "BETA-002",  1, 49.99),
        Product("Product Gamma", "GAMMA-003", 1, 79.99)
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCatalogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        applyOffer(DEFAULT_OFFER)
        setupClickListeners()
        loadTargetOffer()
    }

    override fun onResume() {
        super.onResume()
        if (!isHidden) trackScreen()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden) trackScreen()
    }

    private fun trackScreen() {
        AEPTracker.trackScreenView(SCREEN_NAME, SCREEN_SECTION)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    // ─── TARGET ──────────────────────────────────────────────────────────────

    override fun reloadTargetOffer() {
        loadTargetOffer()
    }

    private fun loadTargetOffer() {
        TargetManager.getJsonOffer(
            mboxName     = TargetManager.MBOX_CATALOG_BANNER,
            defaultOffer = DEFAULT_OFFER,
            loyalty      = LoyaltyLevel.CURRENT,
            extraMboxParams = mapOf("screenContext" to "catalog")
        ) { offer ->
            activity?.runOnUiThread {
                applyOffer(offer)
                TargetManager.notifyDisplay(TargetManager.MBOX_CATALOG_BANNER)
            }
        }
    }

    private fun applyOffer(offer: TargetOffer) {
        currentOffer = offer
        binding.tvCatalogOfferTitle.text = offer.title
        binding.tvCatalogOfferBody.text  = offer.body
        binding.btnCatalogOfferCta.text  = offer.ctaLabel
        binding.ivCatalogBg.load(offer.backgroundImageUrl) {
            crossfade(true)
            error(android.R.drawable.ic_menu_gallery)
        }
    }

    // ─── CTA ─────────────────────────────────────────────────────────────────

    private fun setupClickListeners() {

        // CTA offerta Target
        binding.btnCatalogOfferCta.setOnClickListener {
            AEPTracker.trackCtaInteraction(currentOffer.ctaTrackingId, currentOffer.ctaLabel, SCREEN_NAME, "offer_banner")
            TargetManager.notifyClick(TargetManager.MBOX_CATALOG_BANNER)
        }

        // Prodotti
        binding.btnViewProduct1.setOnClickListener { trackProductDetail(products[0]) }
        binding.btnAddCart1.setOnClickListener     { trackAddToCart(products[0]) }
        binding.btnViewProduct2.setOnClickListener { trackProductDetail(products[1]) }
        binding.btnAddCart2.setOnClickListener     { trackAddToCart(products[1]) }
        binding.btnViewProduct3.setOnClickListener { trackProductDetail(products[2]) }
        binding.btnAddCart3.setOnClickListener     { trackAddToCart(products[2]) }
    }

    private fun trackProductDetail(product: Product) {
        AEPTracker.trackCtaInteraction(
            ctaId = "catalog_detail_${product.sku}", ctaLabel = "Detail ${product.name}",
            screenName = SCREEN_NAME, position = "product_card"
        )
        AEPTracker.trackCommerceEvent(CommerceEventType.PRODUCT_VIEW, listOf(product))
    }

    private fun trackAddToCart(product: Product) {
        AEPTracker.trackCtaInteraction(
            ctaId = "catalog_add_cart_${product.sku}", ctaLabel = "Add ${product.name}",
            screenName = SCREEN_NAME, position = "product_card"
        )
        AEPTracker.trackCommerceEvent(CommerceEventType.ADD_TO_CART, listOf(product))
    }
}
