package com.adobe.demoapp

import android.util.Log
import com.adobe.marketing.mobile.Edge
import com.adobe.marketing.mobile.ExperienceEvent

/**
 * AEPTracker — helper centralizzato per gli eventi XDM verso AEP/CJA via Edge Network.
 *
 * Struttura payload per ogni evento:
 *  - application      → campi XDM standard del nodo application (da schema)
 *  - _acssandboxemeatwo.interaction → tutti i campi custom inclusi screenView/appAction
 */
object AEPTracker {

    private const val TAG = "AEPTracker"

    // ─── SCREEN VIEW ─────────────────────────────────────────────────────────

    fun trackScreenView(screenName: String, sectionName: String? = null) {
        val xdmData = mapOf<String, Any>(
            "eventType"   to "application.scene",
            "application" to buildApplicationNode(),
            "environment" to buildEnvironmentNode(),
            "web" to mapOf(
                "webPageDetails" to mapOf(
                    "name"      to screenName,
                    "URL"       to "app://demoapp/$screenName",
                    "pageViews" to mapOf("value" to 1)
                )
            ),
            "_acssandboxemeatwo" to mapOf(
                "interaction" to mapOf(
                    "screenName"   to screenName,
                    "sectionName"  to (sectionName ?: ""),
                    "loyaltyLevel" to LoyaltyLevel.CURRENT.key,
                    "screenView"   to mapOf("value" to 1)
                )
            )
        )
        sendEdgeEvent(xdmData, label = "ScreenView[$screenName]")
    }

    // ─── CTA INTERACTION ─────────────────────────────────────────────────────

    fun trackCtaInteraction(
        ctaId: String,
        ctaLabel: String,
        screenName: String,
        position: String = ""
    ) {
        val xdmData = mapOf<String, Any>(
            "eventType"   to "application.interaction",
            "application" to buildApplicationNode(),
            "environment" to buildEnvironmentNode(),
            "web" to mapOf(
                "webPageDetails" to mapOf(
                    "name" to screenName
                ),
                "webInteraction" to mapOf(
                    "name"       to ctaId,
                    "linkClicks" to mapOf("value" to 1),
                    "type"       to "other"
                )
            ),
            "_acssandboxemeatwo" to mapOf(
                "interaction" to mapOf(
                    "ctaId"        to ctaId,
                    "ctaLabel"     to ctaLabel,
                    "position"     to position,
                    "screenName"   to screenName,
                    "loyaltyLevel" to LoyaltyLevel.CURRENT.key,
                    "appAction"    to mapOf("value" to 1)
                )
            )
        )
        sendEdgeEvent(xdmData, label = "CTA[$ctaId]")
    }

    // ─── COMMERCE ────────────────────────────────────────────────────────────

    fun trackCommerceEvent(
        eventType: CommerceEventType,
        products: List<Product>,
        orderId: String? = null,
        orderTotal: Double? = null
    ) {
        val productListItems = products.map { product ->
            mutableMapOf<String, Any>(
                "name"         to product.name,
                "SKU"          to product.sku,
                "quantity"     to product.quantity,
                "priceTotal"   to product.price,
                "currencyCode" to "EUR"
            )
        }

        val commerceMap = mutableMapOf<String, Any>()
        when (eventType) {
            CommerceEventType.PRODUCT_VIEW     -> commerceMap["productViews"]        = mapOf("value" to 1)
            CommerceEventType.ADD_TO_CART      -> commerceMap["productListAdds"]     = mapOf("value" to 1)
            CommerceEventType.REMOVE_FROM_CART -> commerceMap["productListRemovals"] = mapOf("value" to 1)
            CommerceEventType.CHECKOUT         -> commerceMap["checkouts"]           = mapOf("value" to 1)
            CommerceEventType.PURCHASE -> {
                commerceMap["purchases"] = mapOf("value" to 1)
                commerceMap["order"] = mapOf(
                    "purchaseID"   to (orderId ?: ""),
                    "priceTotal"   to (orderTotal ?: 0.0),
                    "currencyCode" to "EUR"
                )
            }
        }

        val xdmData = mapOf<String, Any>(
            "eventType"        to "commerce.${eventType.xdmType}",
            "application"      to buildApplicationNode(),
            "environment"      to buildEnvironmentNode(),
            "commerce"         to commerceMap,
            "productListItems" to productListItems,
            "_acssandboxemeatwo" to mapOf(
                "interaction" to mapOf(
                    "loyaltyLevel" to LoyaltyLevel.CURRENT.key
                )
            )
        )
        sendEdgeEvent(xdmData, label = "Commerce[${eventType.name}]")
    }

    // ─── PRIVATE ─────────────────────────────────────────────────────────────

    /**
     * Nodo XDM "application" — campi standard dello schema AEP.
     *
     * I campi lifecycle (isLaunch, isClose, isInstall, isUpgrade, closeType,
     * sessionLength) vengono omessi dagli eventi custom: sono rilevanti solo
     * negli eventi di lifecycle generati automaticamente dall'SDK e causano
     * errori di validazione XDM se inviati con valori non corretti.
     */
    private fun buildApplicationNode(): Map<String, Any> = mapOf(
        "id"      to BuildConfig.APPLICATION_ID,
        "name"    to "Adobe Demo App",
        "version" to BuildConfig.VERSION_NAME
    )

    /**
     * Nodo XDM "environment" — discrimina il canale in CJA.
     * "type" = "application" per mobile Android/iOS.
     * "type" = "browser"     per Web SDK (alloy, impostato automaticamente).
     *
     * Questo è il campo che in CJA permette di segmentare
     * web vs mobile senza alcuna logica custom.
     */
    private fun buildEnvironmentNode(): Map<String, Any> = mapOf(
        "type"            to "application",
        "operatingSystem" to "Android"
    )

    private fun sendEdgeEvent(xdmData: Map<String, Any>, label: String = "Event") {
        val event = ExperienceEvent.Builder()
            .setXdmSchema(xdmData)
            .build()

        Edge.sendEvent(event) { handles ->
            handles.forEach { handle ->
                Log.d(TAG, "Edge response [$label] type=${handle.type}")
            }
        }
        Log.d(TAG, "Sent: $label")
    }

    // ─── DATA CLASSES ─────────────────────────────────────────────────────────

    data class Product(
        val name: String,
        val sku: String,
        val quantity: Int = 1,
        val price: Double = 0.0
    )

    enum class CommerceEventType(val xdmType: String) {
        PRODUCT_VIEW("productViews"),
        ADD_TO_CART("productListAdds"),
        REMOVE_FROM_CART("productListRemovals"),
        CHECKOUT("checkouts"),
        PURCHASE("purchases")
    }
}
