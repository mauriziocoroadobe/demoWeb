package com.adobe.demoapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import coil.load
import com.adobe.marketing.mobile.MobileCore
import com.adobe.marketing.mobile.edge.consent.Consent
import com.adobe.marketing.mobile.edge.identity.Identity as EdgeIdentity
import com.adobe.marketing.mobile.edge.identity.IdentityMap
import com.adobe.demoapp.databinding.FragmentProfileBinding

/**
 * ProfileFragment — location Target: "profile_loyalty_offer"
 *
 * Include il LOYALTY LEVEL SWITCHER per simulare audience diverse in Target.
 * Il livello viene:
 *  - letto da SharedPreferences all'avvio (LoyaltyLevel.load)
 *  - salvato su SharedPreferences al cambio (LoyaltyLevel.save via MainActivity)
 *  - propagato a Target via UserProfile + mbox params
 *  - usato per invalidare la cache Optimize e ri-fettare le offerte
 */
class ProfileFragment : Fragment(), TargetOfferHost {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    companion object {
        const val SCREEN_NAME    = "Profile"
        const val SCREEN_SECTION = "Account"

        val DEFAULT_OFFER = TargetOffer(
            screen             = "profile",
            title              = "Complete your profile",
            body               = "Add your preferences and unlock personalized recommendations.",
            backgroundImageUrl = "https://images.unsplash.com/photo-1607082349566-187342175e2f?w=1200&q=80&auto=format&fit=crop",
            ctaLabel           = "Update preferences",
            ctaTrackingId      = "profile_offer_cta_default"
        )
    }

    private var currentOffer: TargetOffer = DEFAULT_OFFER

    // ─── LIFECYCLE ───────────────────────────────────────────────────────────

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        applyOffer(DEFAULT_OFFER)
        updateLoyaltyUI(LoyaltyLevel.CURRENT)
        setupClickListeners()
        loadTargetOffer()
        loadEcid()
        refreshWebEcid()
        updateLoginUI()
    }

    override fun onResume() {
        super.onResume()
        if (!isHidden) trackScreen()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden) {
            updateLoyaltyUI(LoyaltyLevel.CURRENT)
            loadEcid()
            refreshWebEcid()
            trackScreen()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    // ─── TARGET ──────────────────────────────────────────────────────────────

    override fun reloadTargetOffer() {
        loadTargetOffer()
    }

    private fun loadTargetOffer() {
        TargetManager.getJsonOffer(
            mboxName        = TargetManager.MBOX_PROFILE_OFFER,
            defaultOffer    = DEFAULT_OFFER,
            loyalty         = LoyaltyLevel.CURRENT,
            extraMboxParams = mapOf("screenContext" to "profile")
        ) { offer ->
            activity?.runOnUiThread {
                applyOffer(offer)
                TargetManager.notifyDisplay(TargetManager.MBOX_PROFILE_OFFER)
            }
        }
    }

    private fun applyOffer(offer: TargetOffer) {
        currentOffer = offer
        binding.tvProfileOfferTitle.text = offer.title
        binding.tvProfileOfferBody.text  = offer.body
        binding.btnProfileOfferCta.text  = offer.ctaLabel
        binding.ivProfileBg.load(offer.backgroundImageUrl) {
            crossfade(true)
            error(android.R.drawable.ic_menu_gallery)
        }
    }

    // ─── LOYALTY SWITCHER ────────────────────────────────────────────────────

    /**
     * Aggiorna badge e highlight dei bottoni per riflettere il livello attivo.
     */
    private fun updateLoyaltyUI(level: LoyaltyLevel) {
        binding.tvLoyaltyBadge.text = "${level.badgeEmoji} ${level.displayName.uppercase()}"

        // Reset tutti i bottoni
        binding.btnLoyaltyBronze.alpha = 0.45f
        binding.btnLoyaltySilver.alpha = 0.45f
        binding.btnLoyaltyGold.alpha   = 0.45f

        // Evidenzia il livello attivo
        when (level) {
            LoyaltyLevel.BRONZE -> binding.btnLoyaltyBronze.alpha = 1.0f
            LoyaltyLevel.SILVER -> binding.btnLoyaltySilver.alpha = 1.0f
            LoyaltyLevel.GOLD   -> binding.btnLoyaltyGold.alpha   = 1.0f
        }
    }

    private fun onLoyaltySelected(newLevel: LoyaltyLevel) {
        if (newLevel == LoyaltyLevel.CURRENT) return

        updateLoyaltyUI(newLevel)

        AEPTracker.trackCtaInteraction(
            ctaId      = "loyalty_switch_${newLevel.key}",
            ctaLabel   = "Switch to ${newLevel.displayName}",
            screenName = SCREEN_NAME,
            position   = "loyalty_switcher"
        )

        // Delega a MainActivity: aggiorna UserProfile, svuota cache, ri-fetcha
        (activity as? MainActivity)?.onLoyaltyLevelChanged(newLevel)

        Toast.makeText(
            requireContext(),
            "${newLevel.badgeEmoji} Loyalty level: ${newLevel.displayName}\nOfferte Target aggiornate",
            Toast.LENGTH_SHORT
        ).show()
    }

    // ─── TRACKING ────────────────────────────────────────────────────────────

    private fun trackScreen() {
        AEPTracker.trackScreenView(SCREEN_NAME, SCREEN_SECTION)
    }

    // ─── CTA ─────────────────────────────────────────────────────────────────

    private fun setupClickListeners() {

        // Loyalty switcher
        binding.btnLoyaltyBronze.setOnClickListener { onLoyaltySelected(LoyaltyLevel.BRONZE) }
        binding.btnLoyaltySilver.setOnClickListener { onLoyaltySelected(LoyaltyLevel.SILVER) }
        binding.btnLoyaltyGold.setOnClickListener   { onLoyaltySelected(LoyaltyLevel.GOLD)   }

        // CTA offerta Target
        binding.btnProfileOfferCta.setOnClickListener {
            AEPTracker.trackCtaInteraction(currentOffer.ctaTrackingId, currentOffer.ctaLabel, SCREEN_NAME, "offer_banner")
            TargetManager.notifyClick(TargetManager.MBOX_PROFILE_OFFER)
        }

        binding.btnEditProfile.setOnClickListener {
            AEPTracker.trackCtaInteraction("profile_edit", "Edit profile", SCREEN_NAME, "account_settings")
        }
        binding.btnOrderHistory.setOnClickListener {
            AEPTracker.trackCtaInteraction("profile_orders", "Order history", SCREEN_NAME, "account_settings")
        }
        binding.btnNotifications.setOnClickListener {
            AEPTracker.trackCtaInteraction("profile_notifications", "Notification preferences", SCREEN_NAME, "account_settings")
        }
        binding.btnConsentYes.setOnClickListener {
            updateConsent(true)
            AEPTracker.trackCtaInteraction("profile_consent_optin", "I consent", SCREEN_NAME, "privacy")
            Toast.makeText(requireContext(), "✓ Consent: OPT-IN", Toast.LENGTH_SHORT).show()
        }
        binding.btnConsentNo.setOnClickListener {
            updateConsent(false)
            AEPTracker.trackCtaInteraction("profile_consent_optout", "Revoke consent", SCREEN_NAME, "privacy")
            Toast.makeText(requireContext(), "✕ Consent: OPT-OUT", Toast.LENGTH_SHORT).show()
        }
        binding.btnLogout.setOnClickListener {
            AEPTracker.trackCtaInteraction("profile_logout", "Logout", SCREEN_NAME, "footer")
            TargetManager.clearCache()
        }

        binding.btnLogin.setOnClickListener {
            if (LoginManager.isLoggedIn) {
                // Logout
                LoginManager.logout {
                    activity?.runOnUiThread {
                        AEPTracker.trackCtaInteraction("profile_crmid_logout", "CRMID Logout", SCREEN_NAME, "authentication")
                        Toast.makeText(requireContext(), "🔓 Logged out — back to anonymous", Toast.LENGTH_SHORT).show()
                        updateLoginUI()
                    }
                }
            } else {
                // Login
                LoginManager.login { crmid ->
                    activity?.runOnUiThread {
                        AEPTracker.trackCtaInteraction("profile_crmid_login", "CRMID Login", SCREEN_NAME, "authentication")
                        Toast.makeText(requireContext(), "🔑 Logged in — CRMID: $crmid", Toast.LENGTH_LONG).show()
                        updateLoginUI()
                    }
                }
            }
        }

        binding.btnStartAssurance.setOnClickListener {
            showAssuranceDialog()
        }

        binding.btnResetIdentity.setOnClickListener {
            showResetIdentityDialog()
        }
    }

    private fun updateConsent(granted: Boolean) {
        Consent.update(mapOf("consents" to mapOf("collect" to mapOf("val" to if (granted) "y" else "n"))))
    }

    /**
     * Legge e mostra il web ECID ricevuto dal deep link, se presente.
     * Chiamato da MainActivity dopo handleWebEcidIntent e al ritorno sul profilo.
     */
    /**
     * Aggiorna il bottone login e la visualizzazione del CRMID
     * in base allo stato corrente di LoginManager.
     */
    private fun updateLoginUI() {
        if (LoginManager.isLoggedIn) {
            val crmid = LoginManager.getCrmId() ?: ""
            binding.layoutCrmid.visibility = android.view.View.VISIBLE
            binding.tvCrmid.text = crmid
            binding.btnLogin.text = "🔓  Logout (CRMID active)"
            binding.btnLogin.backgroundTintList =
                android.content.res.ColorStateList.valueOf(0xFF3A1A1A.toInt())
            binding.btnLogin.setTextColor(0xFFEE5555.toInt())
        } else {
            binding.layoutCrmid.visibility = android.view.View.GONE
            binding.btnLogin.text = "🔑  Login (simulate)"
            binding.btnLogin.backgroundTintList =
                android.content.res.ColorStateList.valueOf(0xFF1A3A1A.toInt())
            binding.btnLogin.setTextColor(0xFF55EE55.toInt())
        }
    }

    fun refreshWebEcid() {
        val webEcid = WebEcidHolder.get()
        activity?.runOnUiThread {
            if (webEcid != null) {
                binding.layoutWebEcid.visibility = android.view.View.VISIBLE
                binding.tvWebEcid.text = webEcid
            } else {
                binding.layoutWebEcid.visibility = android.view.View.GONE
            }
        }
    }

    /**
     * Legge l'ECID tramite EdgeIdentity e lo mostra nella UI.
     * Viene richiamato anche dopo il reset identity per mostrare il nuovo ID.
     */
    private fun loadEcid() {
        binding.tvEcid.text = "Loading…"
        EdgeIdentity.getIdentities { identityMap ->
            val ecid = identityMap
                ?.getIdentityItemsForNamespace("ECID")
                ?.firstOrNull()
                ?.id
                ?: "Not available"
            activity?.runOnUiThread {
                binding.tvEcid.text = ecid
            }
        }
    }

    private fun showAssuranceDialog() {
        val input = android.widget.EditText(requireContext()).apply {
            hint = "Paste Session ID here"
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(0xFF555577.toInt())
            background = null
            setPadding(0, 16, 0, 16)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }

        val container = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            addView(input)
        }

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("🔵 Start Assurance Session")
            .setMessage("Paste the Session ID from AEP → Assurance → Create Session → Deep Link")
            .setView(container)
            .setPositiveButton("Connect") { _, _ ->
                val sessionId = input.text.toString().trim()
                if (sessionId.isNotEmpty()) {
                    // Costruisce l'URL completo se l'utente ha incollato solo l'ID
                    val url = if (sessionId.startsWith("adobedemoapp://") || sessionId.startsWith("http")) {
                        sessionId
                    } else {
                        "adobedemoapp://?adb_validation_sessionid=$sessionId"
                    }
                    AssuranceManager.startSessionFromUrl(url)
                    Toast.makeText(requireContext(), "🔵 Assurance session started", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Please enter a Session ID", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showResetIdentityDialog() {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Reset Identity")
            .setMessage("This will generate a new ECID and reset all identities, simulating a fresh install.\n\nTarget will treat this as a completely new visitor.\n\nContinue?")
            .setPositiveButton("Reset") { _, _ -> performIdentityReset() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performIdentityReset() {
        // 1. Reset ECID e tutte le identità
        com.adobe.marketing.mobile.MobileCore.resetIdentities()

        // 2. Svuota cache Optimize e propositionCache
        TargetManager.clearCache()

        // 3. Resetta login (CRMID) — resetIdentities() ha già azzerato l'identity map
        LoginManager.resetAll()
        WebEcidHolder.clear()
        updateLoginUI()
        refreshWebEcid()

        // 4. Re-registra il token FCM sul nuovo ECID
        PushPermissionHelper.fetchAndRegisterToken()

        // 4. Re-prefetch offerte con nuovo visitor
        TargetManager.prefetchAllOffers(LoyaltyLevel.CURRENT)

        // 5. Ricarica l'offerta di questo screen
        loadTargetOffer()

        // 6. Aggiorna ECID visualizzato (sarà il nuovo ID)
        loadEcid()

        // 7. Feedback visivo
        Toast.makeText(
            requireContext(),
            "✅ Identity reset — new ECID generated.\nTarget will assign a new experience.",
            Toast.LENGTH_LONG
        ).show()

        android.util.Log.d("ProfileFragment", "Identity reset performed")
    }
}
