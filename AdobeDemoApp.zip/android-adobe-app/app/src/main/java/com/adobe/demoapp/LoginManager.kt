package com.adobe.demoapp

import android.util.Log
import com.adobe.marketing.mobile.edge.identity.AuthenticatedState
import com.adobe.marketing.mobile.edge.identity.Identity as EdgeIdentity
import com.adobe.marketing.mobile.edge.identity.IdentityItem
import com.adobe.marketing.mobile.edge.identity.IdentityMap

/**
 * LoginManager — gestione login simulato con CRMID.
 *
 * REGOLE PRIMACY:
 *
 *  Utente NON loggato:
 *    ECID_app  → primary=true   (SDK-managed, default)
 *    ECID_web  → primary=false  (aggiunto da handleWebEcidIntent)
 *
 *  Utente LOGGATO:
 *    CRMID     → primary=true   ← diventa l'identità primaria
 *    ECID_app  → primary=false  ← declassato esplicitamente
 *    ECID_web  → primary=false  ← invariato
 *
 *  Lo stato di login è IN MEMORY ONLY — non persiste tra avvii.
 *  Ogni avvio dell'app parte da stato anonimo pulito.
 */
object LoginManager {

    private const val TAG       = "LoginManager"
    private const val NAMESPACE = "CRMID"

    // In-memory only — pulito ad ogni avvio
    private var crmId: String? = null

    val isLoggedIn: Boolean get() = crmId != null
    fun getCrmId(): String?  = crmId

    // ─── LOGIN ────────────────────────────────────────────────────────────────

    /**
     * Simula il login:
     *  1. Legge l'ECID_app corrente dall'SDK
     *  2. Imposta CRMID primary=true
     *  3. Declassa ECID_app a primary=false
     *  4. ECID_web rimane primary=false (già impostato da handleWebEcidIntent)
     */
    fun login(onComplete: (String) -> Unit) {
        val generated = "DEMO_USR_${LoyaltyLevel.CURRENT.key.uppercase()}_001"
        crmId = generated

        // Legge l'ECID_app corrente per poterlo ri-impostare con primary=false
        EdgeIdentity.getIdentities { identityMap ->
            // L'ECID_app è il primo con primary=true nel namespace ECID
            val appEcidItem = identityMap
                ?.getIdentityItemsForNamespace("ECID")
                ?.firstOrNull { it.isPrimary }

            val newMap = IdentityMap()

            // CRMID: primary=true — diventa l'identità primaria
            newMap.addItem(
                IdentityItem(generated, AuthenticatedState.AUTHENTICATED, true),
                NAMESPACE
            )

            // ECID_app: primary=false — declassato esplicitamente
            if (appEcidItem != null) {
                newMap.addItem(
                    IdentityItem(appEcidItem.id, AuthenticatedState.AMBIGUOUS, false),
                    "ECID"
                )
                Log.d(TAG, "ECID_app declassato a primary=false: ${appEcidItem.id}")
            }

            // ECID_web: già primary=false, non serve aggiornarlo

            EdgeIdentity.updateIdentities(newMap)

            Log.d(TAG, "Login: CRMID=$generated (primary=true) — identity map aggiornata")
            onComplete(generated)
        }
    }

    // ─── LOGOUT ───────────────────────────────────────────────────────────────

    /**
     * Logout:
     *  1. Rimuove il CRMID dall'identity map
     *  2. Ripristina ECID_app a primary=true
     */
    fun logout(onComplete: () -> Unit) {
        val previous = crmId ?: return
        crmId = null

        // Legge ECID_app corrente (ora primary=false per via del login)
        EdgeIdentity.getIdentities { identityMap ->
            val appEcidItem = identityMap
                ?.getIdentityItemsForNamespace("ECID")
                ?.firstOrNull()   // al logout il primo è ancora l'app ECID

            // Rimuove il CRMID
            EdgeIdentity.removeIdentity(IdentityItem(previous), NAMESPACE)

            // Ripristina ECID_app a primary=true
            if (appEcidItem != null) {
                val restoreMap = IdentityMap()
                restoreMap.addItem(
                    IdentityItem(appEcidItem.id, AuthenticatedState.AMBIGUOUS, true),
                    "ECID"
                )
                EdgeIdentity.updateIdentities(restoreMap)
                Log.d(TAG, "ECID_app ripristinato a primary=true: ${appEcidItem.id}")
            }

            Log.d(TAG, "Logout: CRMID=$previous rimosso")
            onComplete()
        }
    }

    // ─── RESET ────────────────────────────────────────────────────────────────

    /**
     * Chiamato da performIdentityReset() nel ProfileFragment.
     * resetIdentities() ha già azzerato tutto — qui puliamo solo lo stato interno.
     */
    fun resetAll() {
        crmId = null
        Log.d(TAG, "LoginManager: reset completo")
    }
}
