package com.adobe.demoapp

/**
 * WebEcidHolder
 *
 * Mantiene in memoria il web ECID ricevuto dal deep link.
 * Viene impostato da MainActivity quando il parametro web_ecid
 * è presente nell'intent, e letto da ProfileFragment per mostrarlo in UI.
 *
 * Non viene persistito: viene perso al riavvio dell'app (comportamento corretto —
 * un nuovo avvio senza deep link è una nuova sessione senza stitching web).
 */
object WebEcidHolder {
    private var webEcid: String? = null

    fun set(ecid: String) {
        webEcid = ecid
    }

    fun get(): String? = webEcid

    fun clear() {
        webEcid = null
    }
}
